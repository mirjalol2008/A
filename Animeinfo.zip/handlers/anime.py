from aiogram import Router, types
import requests

router = Router()

@router.message(commands=["anime"])
async def ask_anime_name(message: types.Message):
    await message.answer("🔍 Qidirilayotgan anime nomini yuboring:")

@router.message(lambda m: m.reply_to_message and "Qidirilayotgan anime" in m.reply_to_message.text)
async def search_anime(message: types.Message):
    query = message.text
    url = f"https://api.jikan.moe/v4/anime?q={query}&limit=1"

    try:
        response = requests.get(url)
        data = response.json()

        if "data" in data and len(data["data"]) > 0:
            anime = data["data"][0]
            title = anime.get("title", "Noma'lum")
            synopsis = anime.get("synopsis", "Izoh mavjud emas.")[:500]
            episodes = anime.get("episodes", "Noma'lum")
            score = anime.get("score", "Noma'lum")
            image_url = anime["images"]["jpg"]["image_url"]
            mal_url = anime.get("url", "https://myanimelist.net")

            caption = (
                f"🎬 <b>{title}</b>\n"
                f"⭐ Reyting: {score}\n"
                f"🎞 Epizodlar: {episodes}\n\n"
                f"📖 <i>{synopsis}</i>\n\n"
                f"🔗 <a href='{mal_url}'>MyAnimeList'da ko‘rish</a>"
            )

            await message.answer_photo(image_url, caption)
        else:
            await message.answer("❌ Anime topilmadi.")
    except Exception as e:
        await message.answer(f"⚠️ Xatolik yuz berdi: {e}")